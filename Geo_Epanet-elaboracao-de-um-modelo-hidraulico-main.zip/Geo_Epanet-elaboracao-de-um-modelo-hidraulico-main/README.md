# Geo_Epanet-elaboracao-de-um-modelo-hidraulico
Repositório do projeto de elaboração de um modelo hidráulico utilizando o QGIS e complementos

O objetivo do tutorial é apresentar o passo a passo da minha pesquisa de como elaborar um modelo hidráulico do EPANET utilizando a plataforma de geoprocessamento QGIS, e os plugins qgisred, closest point e line around points, além de diversas ferramentas nativas do QGIS.
a partir da metodologia desenvolvida é possível elaborar um modelo hidráulico completo de uma cidade em pouco tempo. 

As informações contidas no projeto referente ao município União Paulista - SP são fictícias - criados com objetivos didáticos


